# -*- coding: utf-8 -*-
{
    'name': "Actualizacion de precios de estructuras de producto",
    'description': """
        Actualizacion de precios de estructuras de producto
    """,
    'category': 'Fabricacion',
    'version': '20230827',
    'depends': ['stock','purchase','mrp'],
    'data': [
        'views/mrp_views.xml',
    ],
    'license': 'AGPL-3',
}
