# -*- coding: utf-8 -*-

from odoo.exceptions import UserError
from odoo import models
import logging

_logger = logging.getLogger(__name__)

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    def actualizar_precios_productos_terminados(self):
        # raise UserError('hola mundo')
        route_id = self.env.ref('mrp.route_warehouse0_manufacture')
        product_ids = self.search([('route_ids','in',route_id.ids)])
        # raise UserError('{0}'.format(product_ids.ids))
        for product_id in product_ids:
            product_id.button_bom_cost()
        for product_id in product_ids:
            product_id.button_bom_cost()
        return {
            'effect': {
                'type': 'rainbow_man',
                'message': "Precios de Productos Terminados Actualizados",
            }
        }
