from odoo import api, fields, models
from odoo.tools import float_compare


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    warehouse_ids = fields.One2many('order.line.warehouse', 'so_line_id', string="Order Line Warehouse Configuration",
                                    compute="_compute_warehouse_ids_lines", store=True, readonly=False)

    def _is_auto_select_warehouse_qty(self):
        return self.env['ir.config_parameter'].sudo().get_param('sale.auto_select_warehouse_qty')

    @api.depends('product_id', 'product_uom', 'product_uom_qty')
    def _compute_warehouse_ids_lines(self):
        if self._is_auto_select_warehouse_qty():
            for so_line in self:
                warehouse_line = []
                order = so_line.order_id
                default_warehouse = order.warehouse_id
                warehouse_ids = self.env['stock.warehouse'].search([('company_id', '=', so_line.order_id.company_id.id)])

                # first check quantity is available in the default warehouse  and set it to the warehouse_ids
                need = so_line.product_uom_qty
                print("default_warehouse : ", default_warehouse)
                if default_warehouse:
                    available_qty = so_line.product_id.with_context(warehouse=default_warehouse.id).qty_available
                    if available_qty:
                        print("available_qty : ", available_qty)
                        if available_qty >= need:
                            warehouse_line.append((0, 0, {'warehouse_id': default_warehouse.id, 'qty': need}))
                            need = 0
                        else:
                            warehouse_line.append((0, 0, {'warehouse_id': default_warehouse.id, 'qty': available_qty}))
                            need = need - available_qty
                print("need : ", need)
                if need:
                    # if still some quantity is remaining then check in other warehouses and set it to the warehouse_ids
                    for warehouse in warehouse_ids:
                        if warehouse == default_warehouse:
                            continue
                        available_qty = so_line.product_id.with_context(warehouse=warehouse.id).qty_available
                        if available_qty:
                            if available_qty >= need:
                                warehouse_line.append((0, 0, {'warehouse_id': warehouse.id, 'qty': need}))
                                need = 0
                            else:
                                warehouse_line.append((0, 0, {'warehouse_id': warehouse.id, 'qty': available_qty}))
                                need = need - available_qty
                        if not need:
                            break
                if so_line.warehouse_ids:
                    so_line.warehouse_ids.unlink()
                so_line.warehouse_ids = warehouse_line
        else:
            for so_line in self:
                warehouse_line = []
                if so_line.warehouse_ids:
                    so_line.warehouse_ids.unlink()
                for warehouse in self.env['stock.warehouse'].search([('company_id', '=', so_line.order_id.company_id.id)]):
                    warehouse_line.append((0, 0, {'warehouse_id': warehouse.id, 'qty': 0}))
                so_line.warehouse_ids = warehouse_line

    def select_warehouse_quantity_wizard(self):
        wizard_id = self.env.ref('warehouse_selector_sale_orders.sale_order_line_warehouse_selection_view').id
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'sale.order.line',
            'view_type': 'form',
            'view_id': wizard_id,
            'view_mode': 'form',
            'res_id': self.id,
            'target': 'new',
            "context": {"create": False},
        }

    def _action_launch_stock_rule(self, previous_product_uom_qty=False):
        """
        Launch procurement group run method with required/custom fields genrated by a
        sale order line. procurement group will launch '_run_pull', '_run_buy' or '_run_manufacture'
        depending on the sale order line product rule.
        """
        if self._context.get("skip_procurement"):
            return True
        precision = self.env['decimal.precision'].precision_get('Product Unit of Measure')
        procurements = []
        for line in self:
            line = line.with_company(line.company_id)
            if line.state != 'sale' or not line.product_id.type in ('consu', 'product'):
                continue
            qty = line._get_qty_procurement(previous_product_uom_qty)
            if float_compare(qty, line.product_uom_qty, precision_digits=precision) == 0:
                continue

            group_id = line._get_procurement_group()
            if not group_id:
                group_id = self.env['procurement.group'].create(line._prepare_procurement_group_vals())
                line.order_id.procurement_group_id = group_id
            else:
                # In case the procurement group is already created and the order was
                # cancelled, we need to update certain values of the group.
                updated_vals = {}
                if group_id.partner_id != line.order_id.partner_shipping_id:
                    updated_vals.update({'partner_id': line.order_id.partner_shipping_id.id})
                if group_id.move_type != line.order_id.picking_policy:
                    updated_vals.update({'move_type': line.order_id.picking_policy})
                if updated_vals:
                    group_id.write(updated_vals)

            for warehouse in line.warehouse_ids:
                values = line._prepare_procurement_values(group_id=group_id)
                values['warehouse_id'] = warehouse.warehouse_id
                product_qty = warehouse.qty
                line_uom = line.product_uom
                quant_uom = line.product_id.uom_id
                product_qty, procurement_uom = line_uom._adjust_uom_quantities(product_qty, quant_uom)
                procurements.append(self.env['procurement.group'].Procurement(
                    line.product_id, product_qty, procurement_uom,
                    line.order_id.partner_shipping_id.property_stock_customer,
                    line.name, line.order_id.name, line.order_id.company_id, values))

            remaining_qty = line.product_uom_qty - sum(line.warehouse_ids.mapped('qty'))
            if remaining_qty > 0:
                values = line._prepare_procurement_values(group_id=group_id)
                product_qty = remaining_qty
                line_uom = line.product_uom
                quant_uom = line.product_id.uom_id
                product_qty, procurement_uom = line_uom._adjust_uom_quantities(product_qty, quant_uom)
                procurements.append(self.env['procurement.group'].Procurement(
                    line.product_id, product_qty, procurement_uom,
                    line.order_id.partner_shipping_id.property_stock_customer,
                    line.name, line.order_id.name, line.order_id.company_id, values))
        if procurements:
            self.env['procurement.group'].run(procurements)

        # This next block is currently needed only because the scheduler trigger is done by picking confirmation rather than stock.move confirmation
        orders = self.mapped('order_id')
        for order in orders:
            pickings_to_confirm = order.picking_ids.filtered(lambda p: p.state not in ['cancel', 'done'])
            if pickings_to_confirm:
                # Trigger the Scheduler for Pickings
                pickings_to_confirm.action_confirm()
        return True

    def close_action_window(self):
        return True
