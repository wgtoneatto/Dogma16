> **No me gusta mi camisa**
>
> *Version affectada:*
> 
>  - 7.0 y encima
> 
> *Pasos para reproducir:*
> 
>  1. ponerse antes de un espejo
>  2. prender la luz
>  3. abrir los ojos
> 
> *Lo que pasa actualmente:*
> 
>  - Asusto
> 
> *Lo que debe pasar:*
> 
>  - Todo bien, listo para la fiesta 
>
> *Analisis profunda:*
>
>  - Yo cre que la causa raiz es...
>  - Yo creo que es relevante, pensar en...
>  - Yo he encontrado los siguientes vinculos que se relacionan al tema...
>  - Yo creo que es relacionado a los siguientes "issues"...
