# -*- coding: utf-8 -*-
from . import pos_session
from . import pos_order
from . import res_partner
