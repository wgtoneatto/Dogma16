{
    "name": "Listado de Bancos Argentinos",
    'version': "16.0.1.3.0",
    'category': 'Localization/Argentina',
    'sequence': 14,
    'author': 'ADHOC SA',
    'license': 'AGPL-3',
    'summary': '',
    'depends': [
        'base',
    ],
    'data': [
        'data/res_bank.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}
