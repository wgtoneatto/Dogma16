##############################################################################
# For copyright and license notices, see __manifest__.py file in module root
# directory
##############################################################################
from . import account_account
from . import account_account_tag
from . import account_chart_template
from . import account_move
from . import account_move_line
from . import account_tax
from . import afip_padron
from . import res_company
from . import res_currency
from . import res_partner
from . import account_payment
from . import res_config_settings
from . import ir_actions_report
from . import account_journal
from . import account_fiscal_position
