This module is an utility module to add lines in payment, allowing users make
more complicated cases when processing payments, split on many invoices,
set up specific write-off and adding some analytic information

Add tool to proposal of payment distributions, ordering by due date
